<?php

namespace App\Http\Controllers\API\APP;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use App\user;
use App\post;
use App\like;
use App\comment;
class postController extends Controller
{
	public function store(Request $req)
	{
	    $create =  post::create([
	    	'user_id' => Auth::id(),
	    	'content' => $req->content,
	    	'catg' => Auth::user()->profile->catg,
	    	'subCatg' => $req->subCatg
	    ]);
	    post::where('id',$create->id)->update(['subCatg' => $req->subCatg]);

	    $frinds_id = Auth::user()->frinds_id();
	    foreach ($frinds_id as $k) {
        User::find($k)->notify(new \App\Notifications\postNotfy(Auth::User()));
	    	
	    }
	}

	public function show($user_id)
	{
		return response()->json(User::find($user_id)->posts);
	}


	public function showPost($id)
	{
		return response()->json(Post::where('id',$id)->first());
	}

	public function firstPost(Request $req)
	{
		post::create([
			'user_id' => Auth::id(),
			'content' => $req->content,
			'catg' => Auth::user()->profile->catg
		]);
		user::where('id',Auth::id())->update(['active' => true]);
		
	}

	public function myComment($post_id) 
	{
		return response()->json(comment::where('user_id',Auth::id())->where('post_id',$post_id)->get());
	}

	public function share($post_id)
	{
		$userid = post::where('id',$post_id)->value('user_id');
		if(Auth::id() == $userid) 
		{
			return response()->json(['state' => "You Can't Share Your Post", 'error' => 1]);
		}
		$hasShare = post::where('user_id',Auth::id())->where('postid',$post_id)->count();
		if($hasShare == 0) {
			$post = post::where('id',$post_id)->first();
			$createPost = post::create([
				'user_id' => Auth::id(),
				'content' => $post->content,
				'catg' => Auth::user()->profile->catg,
				'isShare' => 1,
				'postid' => $post_id,
				'subCatg' => $post->subCatg
			]);
			post::where('id',$createPost->id)->update(['isShare' => 1,'postid' => $post_id,'subCatg' => $post->subCatg]);

			User::find($post->user_id)->notify(new \App\Notifications\shareNotfy(Auth::User(),$post_id));

			return response()->json(['state' => 'You Share There This post','error' => 0]);
		}else {
			return response()->json(['state' => 'You Have Share This Post ','error' => 1]);
		}
	}

	public function myPost() {
		return response()->json(Auth::User()->posts);
	}
	public function myLike() {
		$like = like::where('user_id',Auth::id())->get();
		$pluk_id = array();
		foreach ($like as $k) {
			$pluk_id[] = $k->post_id;
		}
		$post = post::where('user_id',Auth::id())->whereIn('id',$pluk_id)->orderBy('id','desc')->get();
		return response()->json($post);
	}
	public function myCommentList() {
		$comment = comment::where('user_id',Auth::id())->get();
		$pluk_id = array();
		foreach ($comment as $k) {
			$pluk_id[] = $k->post_id;
		}
		$post = post::whereIn('id',$pluk_id)->orderBy('id','desc')->get();
		return response()->json($post);
	}
}

<?php

namespace App\Http\Controllers\API\APP;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\user;
use Illuminate\Support\Facades\Auth; 
use Validator;
use DB;
use Carbon\Carbon;
use App\profile;

class userController extends Controller
{
    public function create(Request $request)
    {
        $validator = Validator::make($request->all(), [ 
            'name' => 'required', 
            'phone' => 'required|unique:users', 
            'password' => 'required', 
        ]);

        if ($validator->fails()) { 
            return response()->json(['error'=>$validator->errors()], 401);            
        }
        $input = $request->all(); 
        $input['password'] = bcrypt($input['password']);

       $user =  User::create([
            'name' => $input['name'],
            'phone' => $input['phone'],
            'password' => $input['password'],
            'type' => 0,
            'avatar' => 'avatar.png',
            'active' => false
        ]);
        profile::create(['user_id' => $user->id]);
        $success['token'] =  $user->createToken('ops')-> accessToken; 
        $success['name'] =  $user->name;
        return response()->json(['success'=>$success], 200); 



    }

        public function login() {
        if(Auth::attempt(['phone' => request('phone'), 'password' => request('password')])){ 
            $user = Auth::user(); 
            $success['token'] =  $user->createToken('tfran')-> accessToken; 
            $userApp = new user;
            $type= $userApp::where('phone',request('phone'))->value('type');
            return response()->json(['success' => $success,'type' => $type], 200); 
        } 
        else{ 
            return response()->json(['error'=>'Unauthorised'], 401); 
        }
    }

    public function show($id)
    {
        $user = new user;

        $user = $user::where('id',$id)->firstOrFail();
        $profile = $user->profile;
        if(Auth::user()->id == $id)
        {
            $owner = true;
        }else {
            $owner = false;
        }
        return response()->json(['user' => $user,'profile' => $profile,'owner'=> $owner]);
    }

    public function update(Request $req)
    {
        Auth::user()->update($req->user);
        Auth::user()->profile()->update([
             'location' => $req->profile['country'].', '.$req->profile['city'],
            'about' => $req->profile['about'],
           
        ]);
        return response()->json(['msg' => 200]);
    }
}

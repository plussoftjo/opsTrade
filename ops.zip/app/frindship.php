<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class frindship extends Model
{
    protected $fillable = [
        'req_from','req_to','stauts'
    ]; 
}
